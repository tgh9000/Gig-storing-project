<!-- This is a template for the README.md that you should submit. For instructions on how to get started, see INSTRUCTIONS.md -->
# Design Choices

include unique ID for every table even if there is already a composite key. This is beacuase it prevents repitition of many longer variables ,such as strings, being in multiple places as references which takes up more space. it also allows for faster joins and searching tables with composite keys require more data and comparisons.

prices for each act at a gig should a part of the act table since they are dependant on that so that buisness rule number 3 can be implemented automatically

include a boolean value for each row within each table that requires it to be "complete" before the buisness rules apply to it so that the trigger can always be present instead of having to do it within the task itself.

include the actual end time for each act instead of its duration since it used alot more and therefore would require less recalcualtion when it is required.

You could also break up the gig table by the year they occured to allow for faster lookups since the data is broken up into smaller parts.


<!-- Write suggestions for improving the design of the tables here -->

# Task Implementations

<!-- For each of the tasks below, please write around 100-200 words explaining how your solution works (describing the behaviour of your SQL statements/queries) -->

## Task 1
Task 1 works by retrieving the performance schedule for a specific gig returning act names with their start and end times.

The function takes a database connection and a gigID as parameters to the function. It then constructs an SQL query what joins the act and act_gig_view which has a precomputed value for the end time of every act in a gig in order to retrieve act names alongside their performance times, in ascending order according to their start time.

The function allocates a two-dimensional string array sized to hold all results with three columns per row. It goes over each item in the resultSet, extracting the name, start and end times. the substring is used to get rid of the seconds from the time value.


## Task 2

The task's purpose is to create a new gig in the database and then add all the acts which are associated with that gig.

the function disables autoCommit so that if an error occurs and the changes need to be undone then they can be. It starts by retrieveing the ID of the venue given its name using an SQL query.

Next the array passed into the function is sorted based on the starting time so that we now have a list of all acts in order and therefore can calculate the starting time and end time for checking if it complies with rules 10 and 6. After this all the acts from the list are added to the database.

Next two validation functions are tested to see if the current state of the database follows rules 10 and 6. If this is the case then the changes are commited, if not they are undone.

## Task 3
The first thing the method does is chekcing whether the requested ticket type is valid for this gig. It queries the fif_ticket table to make sure a price type exists for the given gig and pricetype. If none exists then the function is cancelled.

If the validation passes the ticket is inserted into the ticket table with the customer's name, email and price type which defaults to adult. IF all the operations are completed successfully then the transaction is committed to the database.

a catch clause is in place in case there is an error anywhere within the code.

## Task 4

This code is designed to remove an act from a gig while keeping the timing constraints between all other performances.

the method starts by retrieving the act data. If the act does not exist at that gig, then Null will be returned.

all instance of the act at the gig are then deleted from act_gig. the method then calculates how much time is going to be removed from the schedule including both the removed act and the gaps between them. ALL Triggers are disbaled while this update runs to avoid violations.

if all constraints remain valid the transaction is pushed to the database and the updated gig lineup is returned using task1. 
## Task 5
This function queries all acts currently in the databse and computes the following values for them: the total cost of the gig which is the venue plus the cost of all the gigs. Then it calculates the revenue  by suming the cost of all sold tickets.

for each gig, the method compares the total cost with the revenue that has already been earned. It then computes how many additional tickets must be sold to cover the remaining cost (assuming they are of the cheapest type). This is done by dividing the amount that is needed by the cheapest ticket price and rounding up to ensure costs are always fully covered.
## Task 6
This method uses a series of common table expressions to structure a larger query. First, the headline act is identified for each gig by selecting the act with the latest start time given tha tthe gig is still going ahead.

the yearly tickets component joins the headline acts with their name and dates and grouping the results by name and year. It then counts the number of tickets sold per act per year and excludes years with zero sales.

total tickets then adds all these yearly counts to compute the total number of tickets sold for each headling act across all years.

combined_data then merges the yearly figures and overall totals. Each row includes the specific year and ticket count.

Finally, the query selects the act name, year and ticket cound and orders the output by total ticket sales, act name and year with totals listed last. The string returns a two dimensional array or null if there was an error
## Task 7

This method also uses multiple common table expressions to improve the data. First headline_acts determines the headlin act for each gig. THen headline_gigs_with_years associates each headline act with its gig and extracts the year hte gig took place.

act_years finds out how many different  years each act has appeared as a headline act. HOwever, customer_years calculates the number of distinct years each customer has gone to headline gigs for a given act,

regular_customers then finds the customers who attended a headline gig for an act in every year that act headlined which in turn made them a regular. their tital ticket counts are retained for ordering. Acts with no regular customers have an entry of [None]

Finally, all results are combined and given to the program as pairs of act name and customer names. the output is ordered by act anme then by ticket purchases in descending order and then finally by customer name in ascenign order.

## Task 8

The method start by calculate the average ticket price acroll all tickets sold for active gigs by joining the ticket and gig tables together. if no price exists the method returns an empty result set. 

Using this average price as an estimate of future ticket income, the method then evaluates every possible pairing of using a cross join. With each combination, it works out the minimum number of tickets required to cover both teh venue hire and all the act fees. 

only combinations where the required number of tickets is more than the venues capacity. the results are ordered alphabetically by venue name and then then number of required tickets for each venue.